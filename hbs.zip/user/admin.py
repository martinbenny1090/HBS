from django.contrib import admin
from .models import Room, Popularlocations, Hotels
# Register your models here.

admin.site.register(Room)
admin.site.register(Popularlocations)
admin.site.register(Hotels)
